% Compiles external LIC function used in the toolbox. Only necessary in
% non-windows machines
mex fastLICFunction.c
disp('Matlab VFV toolbox is now installed.');