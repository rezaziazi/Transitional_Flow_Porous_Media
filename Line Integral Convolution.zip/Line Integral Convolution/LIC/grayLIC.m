% GRAYLIC is an internal command of the toolbox. It uses Regular LIC method implemented in internal Matlab commands 
% to generate an intensity image.
% Usage:
% [LICIMAGE, INTENSITY,NORMVX,NORMVY] = GRAYLIC(VX, VY, ITERATIONS);
% VX and VY should contain X and Y components of the vector field. They
% should be M x N floating point arrays with equal sizes.
%
% ITERATIONS is an integer number for the number of iterations used in
% Iterative LIC method. use number 2 or 3 to get a more coherent output
% image.
%
% LICIMAGE returns an M x N floating point array containing LIC intensity image 
% INTENSITY returns an M x N floating point array containing magnitude of vector in the field 
% NORMVX and NORMVY contain normalized (each vector is normalized to have
% the length of 1.0) components of the vector field

function [LICImage, intensity,normvx,normvy] = grayLIC(vx,vy, iterations, LIClength, grainSize)

fprintf('Regular LIC iteration time %d\n',iterations);

[width,height] = size(vx);
%LIClength = round(max([width,height]) / 10);
% LIClength = 20;
fprintf('Regular LIC length %d\n',LIClength);
%noiseImage = zeros(width, height);

LICImage = zeros(width, height);
intensity = ones(width, height); % array containing vector intensity

% Making white noise
rand('state',0) % reset random generator to original state

% create primitive noise image
% grainSize = 2;
fprintf('Regular LIC grain size %d\n',grainSize);

noiseImagePrimitive_width = ceil(width/grainSize);
noiseImagePrimitive_height = ceil(height/grainSize);
noiseImagePrimitive = zeros(noiseImagePrimitive_width, noiseImagePrimitive_height);
for i = 1:noiseImagePrimitive_width 
    for j = 1:noiseImagePrimitive_height
        noiseImagePrimitive(i,j)= rand;
    end
end

% for i = 1:width 
%     for j = 1:height
%         noiseImage(i,j)= rand;
%     end
% end

noiseImage = imresize(noiseImagePrimitive,grainSize);

% for i = 1:width 
%     for j = 1:height
%         nX = ceil(i / grainSize);
%         nY = ceil(j / grainSize);
%         noiseImage(i,j)= noiseImagePrimitive(nX, nY);
%     end
% end

% figure('Name', 'Noise');
% imshow(noiseImage)

% Normalize vector field
normvx = zeros(width, height);
normvy = zeros(width, height);
for i = 1:width 
    for j = 1:height
        l = sqrt( vx(i,j)^2 + vy(i,j)^2);
        intensity(i,j) = l;
        if l > 0
            normvx(i,j) = vx(i,j) / l;
            normvy(i,j) = vy(i,j) / l;
        end
    end
end

% Making LIC Image
for m = 1:iterations
for i = 1:width 
    for j = 1:height
        stepCount = 1;
        sum = 0;
        x = i; y = j;
        
        weight = 0;
        
        for k = 1:LIClength * 10 % forward integration
            xPast = x;
            yPast = y;
            
            x = x + normvx(round(x),round(y));
            if x < 1  
                break
            end
            if x > width 
                break
            end
            
            y = y + normvy(round(xPast),round(y));
            if y < 1  
                break
            end
            if y > height 
                break
            end
                
            if (round(x) ~= round(xPast)) || (round(y) ~= round(yPast)) 
                stepCount = stepCount + 1;
                %sum = sum + noiseImage(round(x),round(y));
                sum = sum + 1 / k * noiseImage(round(x),round(y));
                weight = weight + 1 / k;
            end
            
          if stepCount > LIClength 
              break;
          end
          
        end
        
        x = i; y = j;
        
        for k = 1:LIClength * 10 % backward integration
            xPast = x;
            yPast = y;
            
            x = x - normvx(round(x),round(y));
            if x < 1  
                break
            end
            if x > width 
                break
            end
            
            y = y - normvy(round(x),round(y));
            if y < 1  
                break
            end
            if y > height
                break
            end
            
            if (round(x) ~= round(xPast)) || (round(y) ~= round(yPast)) 
                stepCount = stepCount + 1;
                %sum = sum + noiseImage(round(x),round(y));
                sum = sum + 1 / k * noiseImage(round(x),round(y));
                weight = weight + 1 / k;
            end
            
          if stepCount > LIClength * 2 
              break;
          end
          
        end
        %LICImage(i,j) = sum / stepCount;
        LICImage(i,j) = sum / weight;
    end
end
     
%LICImage = imadjust(LICImage); % Adjust the value range
LICImage(isnan(LICImage))=0;
noiseImage = LICImage;
end
%imshow(LICImage);
%figure, imshow(imadjust(LICImage,[],[],2));
%figure, imhist(imadjust(LICImage));